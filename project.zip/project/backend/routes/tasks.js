const express = require('express');
const Task = require('../models/Task');
const auth = require('../middleware/auth');
const router = express.Router();

router.get('/', auth, async (req, res) => {
  const tasks = await Task.find({ createdBy: req.user.id });
  res.json(tasks);
});

router.post('/', auth, async (req, res) => {
  const newTask = new Task({ ...req.body, createdBy: req.user.id });
  const savedTask = await newTask.save();
  const io = req.app.get('io');
  io.emit('refreshTasks', savedTask);
  res.json(savedTask);
});

router.put('/:id', auth, async (req, res) => {
  const updated = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true });
  const io = req.app.get('io');
  io.emit('refreshTasks', updated);
  res.json(updated);
});

router.delete('/:id', auth, async (req, res) => {
  await Task.findByIdAndDelete(req.params.id);
  const io = req.app.get('io');
  io.emit('refreshTasks', { id: req.params.id, deleted: true });
  res.sendStatus(204);
});

module.exports = router;
